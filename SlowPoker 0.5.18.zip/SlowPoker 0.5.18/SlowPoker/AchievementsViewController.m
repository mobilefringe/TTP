//
//  AchievementsViewController.m
//  SlowPoker
//
//  Created by Jamie Simpson on 12-05-06.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "AchievementsViewController.h"
#import "DataManager.h"
#import "AchievementsTableViewCell.h"
#import "AchievementHeaderView.h"

@interface AchievementsViewController ()

@end

@implementation AchievementsViewController

@synthesize _tableView;
@synthesize  scrollToSection;
@synthesize footerView1;
@synthesize footerView2;
@synthesize footerView3;
@synthesize footerView4;
@synthesize footerView5;
@synthesize achievementPlatinumHeaderView;
@synthesize achievementGoldView;
@synthesize achievementSilverHeaderView;
@synthesize achievementBronzeHeaderView;
@synthesize achievementBlackHeaderView;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"Bracelets";
        [[DataManager sharedInstance] addObserver:self forKeyPath:@"addAchievement" options:NSKeyValueObservingOptionOld context:nil];
    }
    return self;
}

-(void)loadView{
    [super loadView];
    self._tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
    _tableView.dataSource = self;
    _tableView.delegate = self;
    _tableView.rowHeight = 85;
    _tableView.frame = CGRectMake(0, 0, 320, 416);
    _tableView.scrollsToTop = YES;
    [self.view addSubview:_tableView];
    
    self.footerView1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 2, 300, 13)];
    footerView1.textAlignment = UITextAlignmentCenter;
    footerView1.textColor = [UIColor darkGrayColor];
    footerView1.font = [UIFont systemFontOfSize:12];
    footerView1.backgroundColor = [UIColor clearColor];
    footerView1.text = @"Collect each card to unlock the Platinum bracelet";
    
    self.footerView2 = [[UILabel alloc] initWithFrame:CGRectMake(0, 2, 300, 13)];
    footerView2.textAlignment = UITextAlignmentCenter;
    footerView2.textColor = [UIColor darkGrayColor];
    footerView2.font = [UIFont systemFontOfSize:12];
    footerView2.backgroundColor = [UIColor clearColor];
    footerView2.text = @"Collect each card to unlock the Gold bracelet";
    
    self.footerView3 = [[UILabel alloc] initWithFrame:CGRectMake(0, 2, 300, 13)];
    footerView3.textAlignment = UITextAlignmentCenter;
    footerView3.textColor = [UIColor darkGrayColor];
    footerView3.font = [UIFont systemFontOfSize:12];
    footerView3.backgroundColor = [UIColor clearColor];
    footerView3.text = @"Collect each card to unlock the Silver bracelet";
    
    self.footerView4 = [[UILabel alloc] initWithFrame:CGRectMake(0, 2, 300, 13)];
    footerView4.textAlignment = UITextAlignmentCenter;
    footerView4.textColor = [UIColor darkGrayColor];
    footerView4.font = [UIFont systemFontOfSize:12];
    footerView4.backgroundColor = [UIColor clearColor];
    footerView4.text = @"Collect each card to unlock the Bronze bracelet";
    
    self.footerView5 = [[UILabel alloc] initWithFrame:CGRectMake(0, 2, 300, 13)];
    footerView5.textAlignment = UITextAlignmentCenter;
    footerView5.textColor = [UIColor darkGrayColor];
    footerView5.font = [UIFont systemFontOfSize:12];
    footerView5.backgroundColor = [UIColor clearColor];
    footerView5.text = @"Collect each card to unlock the Black bracelet";
    
    self.achievementPlatinumHeaderView = [[AchievementHeaderView alloc] initWithFrame:CGRectMake(0, 0, 280, 80)];
    self.achievementGoldView = [[AchievementHeaderView alloc] initWithFrame:CGRectMake(0, 0, 280, 80)];
    self.achievementSilverHeaderView = [[AchievementHeaderView alloc] initWithFrame:CGRectMake(0, 0, 280, 80)];
    self.achievementBronzeHeaderView = [[AchievementHeaderView alloc] initWithFrame:CGRectMake(0, 0, 280, 80)];
    self.achievementBlackHeaderView = [[AchievementHeaderView alloc] initWithFrame:CGRectMake(0, 0, 280, 80)];
}

-(void)viewWillAppear:(BOOL)animated{
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:scrollToSection ];
    [self._tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:NO];
    
}

-(void)viewDidAppear:(BOOL)animated{
    [_tableView flashScrollIndicators];
}

-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    if([keyPath isEqualToString:@"addAchievement"]){
        [_tableView reloadData];
    }
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
	
	// Try to retrieve from the table view a now-unused cell with the given identifier
    static NSString *MyIdentifier = @"PlayerProfileTableViewCell";
    AchievementsTableViewCell *cell = (AchievementsTableViewCell *)[tableView dequeueReusableCellWithIdentifier:MyIdentifier];
    // If no cell is available, create a new one using the given identifier
    if (cell == nil) {
        cell = [[AchievementsTableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:MyIdentifier];
    }
    
    NSMutableArray *gameAchievements;
    NSMutableArray *rowAchievements = [[NSMutableArray alloc] init];
    if(indexPath.section == 0){
        gameAchievements = [[DataManager sharedInstance].gameAchievements valueForKey:@"PLATINUM"];
    }else if(indexPath.section == 1){
        gameAchievements = [[DataManager sharedInstance].gameAchievements valueForKey:@"GOLD"];
    }else if(indexPath.section == 2){
        gameAchievements = [[DataManager sharedInstance].gameAchievements valueForKey:@"SILVER"];
    }else if(indexPath.section == 3){
        gameAchievements = [[DataManager sharedInstance].gameAchievements valueForKey:@"BRONZE"];
    }else if(indexPath.section == 4){
        gameAchievements = [[DataManager sharedInstance].gameAchievements valueForKey:@"BLACK"];
    }
    
    int startingIndex = indexPath.row*4 + 1;
    int endingIndex = startingIndex;
    
    for(int i = 0; i < 4;i++){
        
        if(([gameAchievements count] - 1) >= startingIndex+i){
            endingIndex++;
        }
    }
    
    for (int i=startingIndex; i < endingIndex; i++) {
        [rowAchievements addObject:[gameAchievements objectAtIndex:i]];
    }
    [cell setAchievementData:rowAchievements];
    //cell.textLabel.text = @"Stat Name";
    //cell.detailTextLabel.text = @"Stat Type";
    
    return cell;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 97;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 5;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    if(section == 0){
        NSMutableDictionary *gameAchievement = [[DataManager sharedInstance] getGameAchievementForCode:@"PLATINUM_BRACELET" category:@"PLATINUM"];
        [achievementPlatinumHeaderView setGameAchievement:gameAchievement];
        return achievementPlatinumHeaderView;
    }else if(section == 1){
        NSMutableDictionary *gameAchievement = [[DataManager sharedInstance] getGameAchievementForCode:@"GOLD_BRACELET" category:@"GOLD"];
        [achievementGoldView setGameAchievement:gameAchievement];
        return achievementGoldView;
    }else if(section == 2){
        NSMutableDictionary *gameAchievement = [[DataManager sharedInstance] getGameAchievementForCode:@"SILVER_BRACELET" category:@"SILVER"];
        [achievementSilverHeaderView setGameAchievement:gameAchievement];
        return achievementSilverHeaderView;
    }else if(section == 3){
        NSMutableDictionary *gameAchievement = [[DataManager sharedInstance] getGameAchievementForCode:@"BRONZE_BRACELET" category:@"BRONZE"];
        [achievementBronzeHeaderView setGameAchievement:gameAchievement];
        return achievementBronzeHeaderView;
    }else if(section == 4){
        NSMutableDictionary *gameAchievement = [[DataManager sharedInstance] getGameAchievementForCode:@"BLACK_BRACELET" category:@"BLACK"];
        [achievementBlackHeaderView setGameAchievement:gameAchievement];
        return achievementBlackHeaderView;
    }
    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 85;
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    int achievementsPerRow = 4;
    if(section == 0){
        NSMutableArray *gameAchievements = [[DataManager sharedInstance].gameAchievements valueForKey:@"PLATINUM"];
        int rowCount = ([gameAchievements count]-1)/achievementsPerRow;
        if(([gameAchievements count]-1)%achievementsPerRow > 0){
            rowCount++;
        }
        return rowCount;
    }else if(section == 1){
        NSMutableArray *gameAchievements = [[DataManager sharedInstance].gameAchievements valueForKey:@"GOLD"];
        int rowCount = ([gameAchievements count]-1)/achievementsPerRow;
        if(([gameAchievements count]-1)%achievementsPerRow > 0){
            rowCount++;
        }
        return rowCount;
    }else if(section == 2){
        NSMutableArray *gameAchievements = [[DataManager sharedInstance].gameAchievements valueForKey:@"SILVER"];
        int rowCount = ([gameAchievements count]-1)/achievementsPerRow;
        if(([gameAchievements count]-1)%achievementsPerRow > 0){
            rowCount++;
        }
        return rowCount;
    }else if(section == 3){
        NSMutableArray *gameAchievements = [[DataManager sharedInstance].gameAchievements valueForKey:@"BRONZE"];
        int rowCount = ([gameAchievements count]-1)/achievementsPerRow;
        if(([gameAchievements count]-1)%achievementsPerRow > 0){
            rowCount++;
        }
        return rowCount;
    }else if(section == 4){
        NSMutableArray *gameAchievements = [[DataManager sharedInstance].gameAchievements valueForKey:@"BLACK"];
        int rowCount = ([gameAchievements count]-1)/achievementsPerRow;
        if(([gameAchievements count]-1)%achievementsPerRow > 0){
            rowCount++;
        }
        return rowCount;
    }
    return 1;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    if(section == 0){
        return footerView1;
    }else if(section == 1){
        return footerView2;
    }else if(section == 2){
        return footerView3;
    }else if(section == 3){
        return footerView4;
    }else if(section == 4){
        return footerView5;
    }
    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 14;
}

- (NSIndexPath *)tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return nil;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
