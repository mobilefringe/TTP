//
//  SettingsTableCell.h
//  SlowPoker
//
//  Created by Jamie Simpson on 12-06-25.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingsTableCell : UITableViewCell{
    UIImageView *background;
}

@end
