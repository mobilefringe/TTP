//
//  FacebookInviteViewController.h
//  SlowPoker
//
//  Created by Jamie Simpson on 12-12-17.
//
//

#import <UIKit/UIKit.h>

@interface FacebookInviteViewController : UIViewController

@end
