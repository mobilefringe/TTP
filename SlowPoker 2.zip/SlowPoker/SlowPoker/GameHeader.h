//
//  GameHeader.h
//  SlowPoker
//
//  Created by Jamie Simpson on 12-09-29.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GameHeader : UIView

@end
