//
//  HandEvaluator.m
//  SlowPoker
//
//  Created by Jamie Simpson on 12-04-03.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "HandEvaluator.h"

@implementation HandEvaluator

@synthesize value;
@synthesize type;



@end
