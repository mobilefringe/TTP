//Use your Twitter keys from developer.twitter.com

#define kDEConsumerKey @"SCCP1d6S1TsPWvIUY73A"
#define kDEConsumerSecret @"U5DQzMw56Nsmi4udrRmAZptP4J5IHTovtruZThW5I6g"
