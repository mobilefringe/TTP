//
//  SlowPokerViewController.h
//  SlowPoker
//
//  Created by Jamie Simpson on 12-06-02.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SlowPokerViewController : UIViewController{
    
}



@end
