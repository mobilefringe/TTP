//
//  SlowPokerViewController.m
//  SlowPoker
//
//  Created by Jamie Simpson on 12-06-02.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "SlowPokerViewController.h"

@interface SlowPokerViewController ()

@end

@implementation SlowPokerViewController


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
    }
    return self;
}


-(void)loadView{
    
    [super loadView];
    //self.navigationController.navigationBar.hidden = YES;
    
    
}

-(void)viewWillAppear:(BOOL)animated{
    

    
}


-(void)viewDidAppear:(BOOL)animated{
    
}




@end
